<?php
require_once 'wordpress-tests-lib/includes/functions.php';
function _manually_load_plugin() {
    require dirname( dirname( __FILE__ ) ) . '/push-monkey.php';
}
tests_add_filter( 'muplugins_loaded', '_manually_load_plugin' );

require_once 'wordpress-tests-lib/includes/bootstrap.php';
?>