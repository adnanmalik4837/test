<div class="error push-monkey-us-notice push-monkey-bootstrap" style="background-image:url('<?php echo $image_url; ?>') !important;"> 
	<div class="button-wrapper">
		<a href="<?php echo $upgrade_url; ?>" target="_blank" class="btn btn-success btn-lg">Upgrade Now</a>
	</div>

	<div class="text-wrapper">
		<h4>Congrats! Your website is popular. Continue using Push Monkey in the best way.</h4>
		<p>
		It's time to upgrade your Push Monkey to a higher plan. See our <a target="_blank" href="<?php echo $price_plans; ?>">other great price plans</a>.  
		<a href="http://blog.getpushmonkey.com/2014/12/readers-will-ready-desktop-push-notifications/?source=plugin-upsell" target="_blank">More info &#8594;</a>
		</p>
	</div>

	<div class="close-btn">
			<a href="javascript:void(0);"><img src="<?php echo $close_url; ?>" /></a>
	</div>
</div>