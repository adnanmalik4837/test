<?php

/* File Path Check In WordPress*/
if ( ! defined( 'ABSPATH' ) ) {

	exit;
}
//Model class
class PushMonkeyModel {

	/**
	 * Overwrite this function to uninstall any WordPress options
	 * added/updated by this model.
	 */
	public function uninstall() {
	}
}