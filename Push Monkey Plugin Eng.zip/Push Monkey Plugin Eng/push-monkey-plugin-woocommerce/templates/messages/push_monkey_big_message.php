<div class="error push-monkey-unknown-client push-monkey-bootstrap">
	<div class="button-wrapper text-center">
		<a href="<?php echo $settings_url; ?>" class="btn btn-primary btn-lg btn-block">Sign In</a>
	</div>
	<div class="text-wrapper">
		<h4>You are almost ready to send push notifications!</h4>
		<p>
			Go <a href="<?php echo $settings_url; ?>">here</a> to sign in with your Push Monkey account or create an account on-the-spot.
			<a href="http://www.getpushmonkey.com/help?source=plugin#gpm16" target="_blank">More info about this &#8594;</a>
		</p>
	</div>
</div>
